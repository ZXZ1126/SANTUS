/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWTCCAkGgAwIBAgIUBKvx2MTvnRyYBW/Ef9NGOPHCjGMwDQYJKoZIhvcNAQEL\n\
BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n\
SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTIwMTExMjA2MjY1\n\
OFoXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n\
ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOlFTbmU+mVrolRKoFa4\n\
vAk5TOwFDdTHl2ezQUbTfhnG0ituLrIk6wI46MKNbCZ7dTL9Niz0u4X2VLGGdnsm\n\
9hPTzJ7LAdzA1sJhIPKurv7HniZrI81647AaRsn+8POma/KuSaaVPqfTl7gQA0Uy\n\
IY8uG6XqqILPIW6ShHQINXDK7R2GocFDKyoVYPoi6mUJMx26gKfHFXbFT7a+gLkU\n\
kEkUXxbZUPXkuiZcG2C+p+qyWblfE40UrOSToclW1oNPuQQnHPnXTwNHQ74w/O0p\n\
VMga+7xfl4aQm5aRrSYl39ykkCtYoyIzfmk6pTUz/6MpGNYVexFBGiGuQWvPX4ns\n\
ZDECAwEAAaNgMF4wHwYDVR0jBBgwFoAUhNWDsnx0RcD7I+Uji/sHhGkqgWcwHQYD\n\
VR0OBBYEFJvhpJQw48ClrU6KSFTwtIulzYwpMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n\
AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQCW3RXGyewGgSw8/cQr4jQkMShc\n\
K6PedLcxjd4VGXTLZomgrsEjs25+g34FoL2rEWuwocQcV71BugCfUIgpnHhIQsf3\n\
E6d2/Xo02xDDK6gsO/HqlGBHTwXpUblGJuVIa+ECQAfs5EBlBB/gSLCiQkN/cTt8\n\
URXPlbideYP+IGfU9v4WTEgypFpWTV6max5c+y2rySGNqfQDSjmFbh0Ej+tc9VyS\n\
tTojKU7zeRH4ZxXg+Om9OUSFdk264DvUWAIXWc7fcxCnclAZ6xnHScPZQ2oGOjat\n\
DMf49xAveX6nTWVcZIEod+9R9ii2AOVOnfbVd5qA9tpO6a9MK51uAwTbcwBp\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIEpAIBAAKCAQEA6UVNuZT6ZWuiVEqgVri8CTlM7AUN1MeXZ7NBRtN+GcbSK24u\n\
siTrAjjowo1sJnt1Mv02LPS7hfZUsYZ2eyb2E9PMnssB3MDWwmEg8q6u/seeJmsj\n\
zXrjsBpGyf7w86Zr8q5JppU+p9OXuBADRTIhjy4bpeqogs8hbpKEdAg1cMrtHYah\n\
wUMrKhVg+iLqZQkzHbqAp8cVdsVPtr6AuRSQSRRfFtlQ9eS6JlwbYL6n6rJZuV8T\n\
jRSs5JOhyVbWg0+5BCcc+ddPA0dDvjD87SlUyBr7vF+XhpCblpGtJiXf3KSQK1ij\n\
IjN+aTqlNTP/oykY1hV7EUEaIa5Ba89fiexkMQIDAQABAoIBABsQw3fo5TSnTGpj\n\
Tj9Bp++aCmbIH1a04chScBx7pYHwI6qOWjSpO+tCFx+bsRS19l84KfUFYEymzCTc\n\
6RpY5uxeArvZ6hlm9oQPKPd/dSZymtLyU3Ef9RMVuWjuf56FjLjXqAv//QkT7+KX\n\
WQnKS0KFoweZNnwW9FYUAfJEkY7IhAoRmLy53QAWKpcSFPS4ybJSdhidPYJ+0SKk\n\
c26/zNHRC7UekyIbCRgrQEGNBaAHHNa4JmbdpTMk61eJRN0gBX3Y2QUtABwGpJ0w\n\
PdEU8ng1yMXYtNwkhrt9U/JiGpbN2wwc6LMeIdYHYKCMfk6sPCE4pZ9nB2YqwAyF\n\
yY28SZECgYEA+aPSNlUn9Rlh75uZSSq6ifAnPMD+RbLp5RLAQVSbQuLVsqgHW4Vl\n\
7YDXxEIyOygJZqQVckuLLdfNYnZnHHvhKAvVbk6tyL+314qVyuFtvQDx89Is26J4\n\
qXk9TUYsCmeyF5En8ftUTAWyX3m1mwchdAKyA2Ott3WqCvpfK1bQpTsCgYEA7za4\n\
f/KvSR9F3oqveFRfrpg5ssNBRCAXn+tQDf87GecOrmFG1x3fP0YpbS10E/rs7TsY\n\
cGfH2CwUigxZ1HpFrKX1m+HEwEU33kTzB/xJrjptAQ8ud9sorqV5j7DokFe1rKbZ\n\
q6EwGVXj4/em1NB2yJkNUfhLHDONf1JnPv0uFYMCgYEA7gt93xtyn7BViCLqly9s\n\
cy4SbEdn79R8Xlh0BZgE+VHODq9VXLsmh8Qte1LYDTrPRBXA8Z0BmXRHv9VB25Jx\n\
EDvAiI/z/RJ73seisLQnbWviS+qlpcYWoxweDXqVclKRKxHack+DgX6JKauoNa0m\n\
BDaxwrOhKejEffVjHLOK/5MCgYArY2J9mpgejDSRE9iV27/rHCNDAFVjNOr0D6ta\n\
jpO6tAUerfg6ZmmqwWAcNGVchmPY96IMKVa/J+elzm2ws2jV0thEqOOV+DgU8a6f\n\
ISyAFIrW6VkFVlP/sXXmETFtlOsX4L+UeM0Pm1uVasLw0MrqwY//8Sg2ekdM87ZU\n\
X3mvXwKBgQCDilmpypIWH+rdgGEBc3n+fQnkbbcn2YjNlyX06gN00erFDlSu9/c3\n\
Xi7kj5j6+sj3r5VAFXSPOcqb0ou5zoGLmgSYsovt5QV+uL284Rbf62BonUjDRwWM\n\
SQRFj0LnYrI++CrlQARN6abYf2OLwtEwTqMJfoCiB5q/4Mz23jmHKQ==\n\
-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
